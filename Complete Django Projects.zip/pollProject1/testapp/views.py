from django.shortcuts import render,redirect
from testapp.forms import CreatePollForm
from testapp.models import Poll
# Create your views here.
def home(request):
    polls=Poll.objects.all()
    context={'polls':polls}
    return render(request,'testapp/home.html',context)

def create(request):
    form=CreatePollForm()
    if request.method=='POST':
        form=CreatePollForm(request.POST)
        if form.is_valid():
            print(form.cleaned_data['question'])
            form.save()
            return redirect('/home')
    context={'form':form}
    return render(request,'testapp/create.html',context)

def vote(request,poll_id):
    poll=Poll.objects.get(pk=poll_id)
    if request.method=='POST':
        print(request.POST['poll'])
    context={'poll':poll}
    return render(request,'testapp/vote.html',context)

def result(request,poll_id):
    poll=Poll.objects.get(pk=poll_id)
    context={'poll':poll}
    return render(request,'testapp/results.html',context)
