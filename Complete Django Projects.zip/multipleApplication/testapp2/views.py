from django.shortcuts import render
from django.http import HttpResponse
import datetime
# Create your views here.

def time_information_view(request):
    time=datetime.datetime.now()
    return HttpResponse('<h1>Current date and time is:'+str(time)+'</h1>')
