from django import forms
from django.core import validators

def starts_with_d(value):
    if value[0].lower()!='u':
        raise forms.ValidationError('Name should start with D' )


class StudentFeedbackForm(forms.Form):
    Rollno=forms.IntegerField()
    Name=forms.CharField(validators=[starts_with_d])
    Email=forms.EmailField()
    Feedback=forms.CharField(widget=forms.Textarea,validators=[validators.MinLengthValidator(40)])

    def clean_Name(self):
        print("Validation Name")
        inputname=self.cleaned_data['Name']
        if len(inputname)<5:
            raise forms.ValidationError("The Minimum number of Characters should be 6")
