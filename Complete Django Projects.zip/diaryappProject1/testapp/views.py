from django.shortcuts import render
from testapp.models import Entry
from testapp.forms import EntryForm

# Create your views here.
def index(request):
    entries=Entry.objects.order_by('-date_posted')
    context={'entries':entries}
    return render(request,'testapp/index.html',context)

def add(request):
    form=EntryForm()
    context={'form':form}
    return render(request,'testapp/add.html',context)
