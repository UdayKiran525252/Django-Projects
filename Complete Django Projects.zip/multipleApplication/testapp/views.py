from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def display(request):
    return HttpResponse('<h1>I am Developing a 2 Application in the same project')
