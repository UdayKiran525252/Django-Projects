from django.contrib import admin
from testapp.models import Post
# Register your models here.
admin.site.register(Post)
