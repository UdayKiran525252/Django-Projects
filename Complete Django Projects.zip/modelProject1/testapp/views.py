from django.shortcuts import render
from testapp.models import Book

# Create your views here.
def bookdata(request):
    book_list=Book.objects.all()
    return render(request,'testapp/display.html',{'book_list':book_list})
