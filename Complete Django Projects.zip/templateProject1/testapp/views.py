from django.shortcuts import render
import datetime
# Create your views here.
def information_view(request):
    time=datetime.datetime.now()
    name='Uday'
    age=22
    subject='Django'
    my_dict={'name1':name,'age':age,'subject':subject,'time':time}
    return render(request,'testapp/results.html',my_dict)
