from django.shortcuts import render
from . import forms

# Create your views here.
def student_information_view(request):
    form=forms.StudentForm()
    if request.method=='POST':
        form=forms.StudentForm(request.POST)
        if form.is_valid():
            print("Form Validation Success and Printing Data")
            print("ROll no is:",form.cleaned_data['rollno'])
            print("Name is:",form.cleaned_data['name'])
            print("Marks are:",form.cleaned_data['marks'])

    return render(request,'testapp/input.html',{'form':form})
