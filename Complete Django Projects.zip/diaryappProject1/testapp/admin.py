from django.contrib import admin
from testapp.models import Entry

# Register your models here.
class EntryAdmin(admin.ModelAdmin):
    list_display=['text','date_posted']

admin.site.register(Entry,EntryAdmin)
