from django.shortcuts import render

# Create your views here.
def sports_info_view(request):
    msg1='Rohit Sharma my best Batsman'
    msg2='I Love Mumbai Indians'
    return render(request,'testapp/news.html',{'msg1':msg1,'msg2':msg2})

def movies_info_view(request):
    msg1='I Love Allu Arjun'
    msg2='Duvvada Jagannadham'
    return render(request,'testapp/news.html',{'msg1':msg1,'msg2':msg2})
