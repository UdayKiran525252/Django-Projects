from django.apps import AppConfig


class Testapp2Config(AppConfig):
    name = 'testapp2'
