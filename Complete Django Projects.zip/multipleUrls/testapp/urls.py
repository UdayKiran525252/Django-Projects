from testapp import views
from django.conf.urls import url

urlpatterns = [
    url(r'^first/',views.first_view),
    url(r'^second/',views.second_view),
    url(r'^third/',views.third_view)
]
