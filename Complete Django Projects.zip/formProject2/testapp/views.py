from django.shortcuts import render
from . import forms

# Create your views here.
def studentform(request):
    form=forms.StudentFeedbackForm()
    if request.method=='POST':
        form=forms.StudentFeedbackForm(request.POST)
        if form.is_valid():
            print("Printing Data on to the Console")
            print("Roll no is",form.cleaned_data['Rollno'])
            print("Name is",form.cleaned_data['Name'])
            print("Email is",form.cleaned_data['Email'])
            print("Feedback is",form.cleaned_data['Feedback'])

    return render(request,'testapp/home.html',{'form':form})
