from django.shortcuts import render

# Create your views here.
def name_view(request):
    return render(request,'testapp/name.html')

def age_view(request):
    name=request.session['name']
    request.session['name']=name
    return render(request,'testapp/age.html')

def gf_view(request):
    age=request.session['age']
    request.session['age']=age
    return render(request,'testapp/gf.html')    
