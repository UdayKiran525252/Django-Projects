from django.shortcuts import render
import datetime
# Create your views here.
def display(request):
    date=datetime.datetime.now()
    msg="Hello Friend!!!!very very Good"
    h=int(date.strftime('%H'))
    if h<12:
        msg+='Morning'
    elif h<16:
        msg+='Afternoon'
    elif h<21:
        msg+='Evening'
    else:
        msg+='Goodnight'
    my_dict={'date':date,'msg':msg}
    return render(request,'testapp/display.html',my_dict)
