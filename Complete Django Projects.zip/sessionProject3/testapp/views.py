from django.shortcuts import render
from testapp.forms import AddItemForm

# Create your views here.
def add_item_view(request):
    form=AddItemForm()
    return render(request,'testapp/additem.html',{'form':form})

def display_item_view(request):
    name=request.session['item']
    request.session['name']=name
    return render(request,'testapp/display.html')
