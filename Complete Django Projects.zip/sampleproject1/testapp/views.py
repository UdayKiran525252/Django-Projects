from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def display(request):
        message='<h1>This is my first django Application</h1>'
        return HttpResponse(message)

def good_morning_view(request):
    return HttpResponse('<h2>Hello friend Good Morning</h2>')


def good_afternoon_view(request):
    return HttpResponse('<h2>Hello friend Good Afternoon</h2>')


def good_evening_view(request):
    return HttpResponse('<h2>Hello friend Good Evening</h2>')        
